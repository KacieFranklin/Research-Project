import{l as o,s as r}from"../chunks/BhdH24hT.js";export{o as load_css,r as start};
