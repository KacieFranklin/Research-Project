var s;const e=((s=globalThis.__sveltekit_1bazjy0)==null?void 0:s.base)??"/Research-Project";var a;const t=((a=globalThis.__sveltekit_1bazjy0)==null?void 0:a.assets)??e;export{t as a,e as b};
